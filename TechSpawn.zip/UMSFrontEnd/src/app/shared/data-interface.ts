export class DataInterface {
    _id: string
    firstname : string
    lastname : string
    gender: string
    email: string
    mobile : number
    dob : string
    role: string
    password : string
}
