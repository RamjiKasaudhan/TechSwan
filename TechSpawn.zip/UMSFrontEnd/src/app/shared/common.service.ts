import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Observable } from 'rxjs';
import { DataInterface } from './data-interface';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private sharingObject: any;
  private token:any;
  constructor(private _http: HttpClient) { }
  form: FormGroup = new FormGroup({
    _id: new FormControl(null),
    __v: new FormControl(null),
    firstname: new FormControl('', Validators.required),
    lastname: new FormControl('', Validators.email),
    email: new FormControl('', Validators.email),
    gender: new FormControl('', Validators.required),
    dob: new FormControl('', Validators.required),
    mobile: new FormControl('', [Validators.required, Validators.minLength(10)]),
    role: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    // password: new FormControl('', [Validators.required]),
  });


  initializeFormGroup() {
    this.form.setValue({
      _id: null,
      __v: null,
      firstname: '',
      lastname: '',
      dob: '',
      email: '',
      mobile: '',
      gender: '',
      role: '',
      passwaord: '',
    });
  }


  getAllUser() {
    let apiUrl = "http://localhost:9000/request/employee/";
    return this._http.get(apiUrl);
  }

  addNewEmployee(data: DataInterface): Observable<any> {
    let url = "http://localhost:9000/request/signup/";
    let headers = { 'Content-Type': ' application/json', }
    let body = JSON.stringify(data);
    console.log(data)
    return this._http.post<any[]>(url, body, { 'headers': headers });
  }
  updateUser(empData: DataInterface) {
    let url = "http://localhost:9000/request/update/";
    let headers = { 'Content-Type': ' application/json', }
    // // 'Access-Control-Allow-Origin': '*'
    // // 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, PATCH, DELETE'
    // console.log(empData)
    // console.log(empData._id)
    let body = JSON.stringify(empData);
    return this._http.patch<any>(url + empData._id, body, { 'headers': headers }).subscribe((response) => {
      console.log("Updated");
    }, error => {
      console.log(error)
    })
  }

  deleteUser(_id: any) {
    console.log(_id)
    const url = "http://localhost:9000/request/delete/";
    console.log(url + _id)
    this._http.delete(url + _id).subscribe((response) => {
      console.log("deleted");
    },
      error => {
        console.log(error)
      })
  }

  tokenGenrate(data: any) {
    let tokenUrl = "http://localhost:9000/request/login/";
    //let verifyTokenUrl = "http://localhost:9000/request/post/";
    let headers = { 'Content-Type': ' application/json', }
    let body = JSON.stringify(data);
    console.log(data)
    return this._http.post<any>(tokenUrl, body, { 'headers': headers }).subscribe((response)=> {
      //console.log(response)
      //this.token= response
      this.verifyToken(response)
    }, error => {
      console.log(error)
    })

  }

  verifyToken(genratedToken){
    let verifyTokenUrl = "http://localhost:9000/request/post/";
    // let headers =  {'Content-Type' : 'application/json; charset=utf-8',
    // 'Accept'       : 'application/json',
    // 'Authorization': `Bearer ${genratedToken.token}`,}
    const headers= new HttpHeaders()
  .set('content-type', 'application/json')
  .set('Access-Control-Allow-Origin', '*')
  .set('Authorization', `Bearer ${genratedToken.token}`);
    console.log(genratedToken.token)
    return this._http.post<any>(verifyTokenUrl, { 'headers': headers}).subscribe((response)=> {
      console.log(response)
      this.token= response
    }, error => {
      console.log(error)
    })
  }

  populateForm(employee) {
    this.form.setValue(employee)
  }

  get sharingValue() {
    return this.sharingObject
  }

  set sharingValue(obj) {
    this.sharingObject = obj;
  }

}
