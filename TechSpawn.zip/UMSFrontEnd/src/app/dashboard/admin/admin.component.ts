import { Component, OnInit ,ViewChild, ViewChildren} from '@angular/core';
import { CommonService } from 'src/app/shared/common.service';

import { MatTableDataSource } from '@angular/material/table';
import { DataInterface } from 'src/app/shared/data-interface';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { EmployeeComponent } from '../employee/employee.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  @ViewChildren(MatSort) sort: MatSort;
  @ViewChildren(MatPaginator) paginator: MatPaginator;

  ELEMENT_DATA: DataInterface[] = [];
  dataSource = new MatTableDataSource<DataInterface>(this.ELEMENT_DATA);
  displayedColumns: string[] = ['Name', 'Mobile', 'DOB', 'Gender', 'Action'];

  constructor(private _commonService: CommonService,private dialog: MatDialog, private router : Router) { }

  ngOnInit() :void{
    this.getEmployeeData()
  }
  empObj = {
      _id: '',
      firstname: '',
      lastname: '',
      dob: '',
      email: '',
      mobile: '',
      gender: '',
      role: '',
      passwaord: '',

  }

  getEmployeeData() {

    this.dataSource = new MatTableDataSource();
    this._commonService.getAllUser().subscribe((response: DataInterface[]) => {

      this.dataSource.data = response as DataInterface[];
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.dataSource.filterPredicate = (data, filter) => {
        return this.displayedColumns.some(ele => {
          return ele != 'actions' && data[ele].toLowerCase().indexOf(filter) != -1;
        });
      };
    })
  }
  onEdit(dashboard) {
    this._commonService.populateForm(dashboard)
    // const dialogConfig = new MatDialogConfig();
    // dialogConfig.data = dashboard;
    this._commonService.sharingValue = dashboard
    this.router.navigate(['/user'])

  }
}
