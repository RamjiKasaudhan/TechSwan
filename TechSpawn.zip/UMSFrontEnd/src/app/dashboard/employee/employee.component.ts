import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from "@angular/forms";
import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/common.service';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  data1: any;
  form = new FormGroup({
    _id: new FormControl('', Validators.required),
    firstname: new FormControl('', Validators.required),
    lastname: new FormControl('', Validators.required),
    email: new FormControl('', Validators.email),
    gender: new FormControl('', Validators.required),
    dob: new FormControl('', Validators.required),
    mobile: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    role: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    // password: new FormControl('', [Validators.required]),
  });
  constructor(private fb: FormBuilder, private _commonService: CommonService,
     private router: Router) { }

  ngOnInit() {
    this.data1 = this._commonService.sharingValue
    this.form = this.fb.group({
      _id: this.data1._id,
      firstname: this.data1.firstname,
      lastname: this.data1.lastname,
      gender: this.data1.gender,
      email: this.data1.email,
      dob: this.data1.dob,
      mobile: this.data1.mobile,
      role: this.data1.role,
      password: this.data1.password
    });
  }
  onSubmit(formobj) {

      console.log(formobj)
      //if (!this._commonService.form.get('_id').value)
      this._commonService.updateUser(formobj)
      this._commonService.initializeFormGroup();

      this.router.navigate(['/admin'])
      this._commonService.initializeFormGroup();
  }
}
