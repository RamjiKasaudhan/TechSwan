import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material'
import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/common.service';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { DataInterface } from 'src/app/shared/data-interface';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private _commonService: CommonService) { }
  username: string;
  password: string;

  ngOnInit() {
    // login()   {
    //   if(this.username == 'admin' && this.password == 'admin'){
    //     this.router.navigate(["user"]);
    //    }else {
    //      alert("Invalid credentials");
    //    }
    // }
  }
  form = new FormGroup({
    _id: new FormControl(null),
    firstname: new FormControl('', Validators.required),
    lastname: new FormControl('', Validators.required),
    email: new FormControl('', Validators.email),
    gender: new FormControl(),
    dob: new FormControl('', Validators.required),
    mobile: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    role: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    // password: new FormControl('', [Validators.required]),
  });

  onSubmit(formobj) {
    const userAuth = {
      email: formobj.email,
      password: formobj.password,
    }
    console.log(userAuth)
    this._commonService.tokenGenrate(userAuth)
    console.log("Data Has been Posted");

  }




}
