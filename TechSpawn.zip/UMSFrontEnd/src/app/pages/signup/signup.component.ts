import { ConvertActionBindingResult } from '@angular/compiler/src/compiler_util/expression_converter';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { CommonService } from 'src/app/shared/common.service';
import { DataInterface } from 'src/app/shared/data-interface';




@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  selectGender: string
  Gender: string[] = ['Male', 'Female', 'Others'];
  Role: string[] = ['Admin', 'User'];
  data: DataInterface = {
    _id: "1234",
    lastname: "string",
    firstname: "ramji@98765",
    gender: "true",
    email: "string",
    dob: "1997-08-19T18:00:00.000Z",
    mobile: 982982982,
    role: "string",
    password: "string"

  };

  form = new FormGroup({
    _id: new FormControl(null),
    firstname: new FormControl('', Validators.required),
    lastname: new FormControl('', Validators.required),
    email: new FormControl('', Validators.email),
    gender: new FormControl(),
    dob: new FormControl('', Validators.required),
    mobile: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    role: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    // password: new FormControl('', [Validators.required]),
  });

  constructor(private _commonService: CommonService) { }

  ngOnInit() {
  }


  onSubmit(formobj) {
    //console.log(formobj.dob);

    this._commonService.addNewEmployee(formobj).toPromise().then((data: DataInterface) => {
      //console.log(data);
      console.log("Data Has been Posted");
      this.form.reset();
    });




  }

  onClose() {
    this._commonService.form.reset();
    this._commonService.initializeFormGroup();

  }

}
