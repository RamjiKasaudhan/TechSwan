1 - Go threw the CRUDAPI folder and opne CMD
2- install node module in CRUDAPI serve folder
3 - then run the command - nodemon run start
5 - Go threw the UMSFrontend folder and opne CMD
6- install node module in UMSFrontend serve folder
7 - then run the command - ng serve --open , to open run the main Project

Note - CrudAPI is working perfectly. but there is some issue with UI, I am unable to do the Login functionality lack of time, but login API Authentication
is for Genrate and Verify Token for any user is working. there is some issue with UI that's why I am unable to comlete login functionality, I am passing the
 Authrization Header for verifyToken from the services but it's responding back.

For Checking all module manully router link given below
Login = http://localhost:4200/login - API is working with JWT authentication , but there is Some issue with UI
Signup = http://localhost:4200/signup -  wokring
Admin = http://localhost:4200/admin - working
User = http://localhost:4200/user - working